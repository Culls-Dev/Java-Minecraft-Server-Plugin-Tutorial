mcModeratorPlus - Source distribution

Included:
- Maven project configured for Paper 1.21.4 API (provided scope).
- Commands: /ban, /tempban, /banip, /banlist, /banui, /unban, /unbanip
- GUI pagination for /banui
- Persistent ban storage: plugins/mcModeratorPlus/bans.yml and ipbans.yml

To build the plugin JAR (on your machine):
1. Install Java 17+ and Maven.
2. From the project root (where pom.xml is), run:
   mvn clean package
3. After a successful build, the plugin JAR will be at:
   target/mcModeratorPlus-1.0.0.jar
4. Copy that JAR into your Paper 1.21.4 server's plugins/ folder and start the server.

Notes:
- The project depends on Paper API. Maven repository for Paper is included in pom.xml.
- If you prefer Gradle, you can import these sources into IntelliJ and convert to Gradle.

