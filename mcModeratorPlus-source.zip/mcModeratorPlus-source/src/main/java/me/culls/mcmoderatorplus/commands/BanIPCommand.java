package me.culls.mcmoderatorplus.commands;

import me.culls.mcmoderatorplus.storage.BanManager;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class BanIPCommand implements CommandExecutor {
    private final BanManager manager;

    public BanIPCommand(BanManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("mcmoderatorplus.banip")) {
            sender.sendMessage("§cYou don't have permission to use this.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage("§eUsage: /banip <ip|player> [reason]");
            return true;
        }
        String target = args[0];
        String reason = args.length > 1 ? String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)) : "IP banned";

        String ip = target;
        Player p = Bukkit.getPlayerExact(target);
        if (p != null && p.getAddress() != null) {
            ip = p.getAddress().getAddress().getHostAddress();
            p.kickPlayer("Your IP has been banned: " + reason);
        }

        manager.banIp(ip, reason, -1L, sender.getName());
        Bukkit.broadcastMessage("§c[IPBan] IP " + ip + " was banned by " + sender.getName() + " — " + reason);
        return true;
    }
}
