package me.culls.mcmoderatorplus.commands;

import me.culls.mcmoderatorplus.storage.BanManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class UnbanIPCommand implements CommandExecutor {
    private final BanManager manager;

    public UnbanIPCommand(BanManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("mcmoderatorplus.unbanip")) {
            sender.sendMessage("§cYou don't have permission to use this.");
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage("§eUsage: /unbanip <ip>");
            return true;
        }

        String ip = args[0];
        boolean result = manager.unbanIp(ip);
        if (result) {
            sender.sendMessage("§aUnbanned IP " + ip + ".");
            Bukkit.broadcastMessage("§a[UnbanIP] IP " + ip + " was unbanned by " + sender.getName() + ".");
        } else {
            sender.sendMessage("§cNo active IP ban found for " + ip + ".");
        }
        return true;
    }
}
