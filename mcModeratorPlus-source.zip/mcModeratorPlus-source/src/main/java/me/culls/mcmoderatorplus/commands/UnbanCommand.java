package me.culls.mcmoderatorplus.commands;

import me.culls.mcmoderatorplus.storage.BanManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class UnbanCommand implements CommandExecutor {
    private final BanManager manager;

    public UnbanCommand(BanManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("mcmoderatorplus.unban")) {
            sender.sendMessage("§cYou don't have permission to use this.");
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage("§eUsage: /unban <player>");
            return true;
        }

        String target = args[0];
        boolean result = manager.unban(target);
        if (result) {
            sender.sendMessage("§aUnbanned player " + target + ".");
            Bukkit.broadcastMessage("§a[Unban] " + target + " was unbanned by " + sender.getName() + ".");
        } else {
            sender.sendMessage("§cNo active ban found for " + target + ".");
        }
        return true;
    }
}
