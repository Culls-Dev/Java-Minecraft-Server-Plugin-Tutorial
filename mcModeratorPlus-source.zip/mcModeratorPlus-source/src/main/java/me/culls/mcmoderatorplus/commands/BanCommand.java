package me.culls.mcmoderatorplus.commands;

import me.culls.mcmoderatorplus.storage.BanManager;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.Arrays;

public class BanCommand implements CommandExecutor {
    private final BanManager manager;

    public BanCommand(BanManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("mcmoderatorplus.ban")) {
            sender.sendMessage("§cYou don't have permission to use this.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage("§eUsage: /ban <player> [reason]");
            return true;
        }
        String targetName = args[0];
        String reason = args.length > 1 ? String.join(" ", Arrays.copyOfRange(args, 1, args.length)) : "Banned by an operator";

        OfflinePlayer op = Bukkit.getOfflinePlayer(targetName);
        String ip = null;

        Player online = Bukkit.getPlayerExact(targetName);
        if (online != null) {
            if (online.getAddress() != null) ip = online.getAddress().getAddress().getHostAddress();
            online.kickPlayer("You are banned: " + reason);
        }

        manager.ban(op.getName(), reason, -1L, sender.getName(), ip);
        Bukkit.broadcastMessage("§c[Ban] " + op.getName() + " was banned by " + sender.getName() + " — " + reason);
        return true;
    }
}
