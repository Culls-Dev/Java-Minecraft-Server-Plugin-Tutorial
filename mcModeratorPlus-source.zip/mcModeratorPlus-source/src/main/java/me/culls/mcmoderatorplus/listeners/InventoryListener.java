package me.culls.mcmoderatorplus.listeners;

import me.culls.mcmoderatorplus.storage.BanManager;
import me.culls.mcmoderatorplus.ui.BanUI;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class InventoryListener implements Listener {
    private final BanManager manager;

    public InventoryListener(BanManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        BanUI.handleClick(e, manager);
    }
}
