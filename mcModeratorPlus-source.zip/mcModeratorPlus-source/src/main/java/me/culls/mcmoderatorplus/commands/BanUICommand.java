package me.culls.mcmoderatorplus.commands;

import me.culls.mcmoderatorplus.storage.BanManager;
import me.culls.mcmoderatorplus.ui.BanUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BanUICommand implements CommandExecutor {
    private final BanManager manager;

    public BanUICommand(BanManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command.");
            return true;
        }

        if (!player.hasPermission("mcmoderatorplus.banui")) {
            player.sendMessage("§cYou do not have permission to use this.");
            return true;
        }

        int page = 1;
        if (args.length >= 1) {
            try {
                page = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                player.sendMessage("§cInvalid page number.");
                return true;
            }
        }

        player.openInventory(BanUI.getBanInventory(manager, page));
        return true;
    }
}
