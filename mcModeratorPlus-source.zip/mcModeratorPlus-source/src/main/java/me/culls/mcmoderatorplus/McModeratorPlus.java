package me.culls.mcmoderatorplus;

import me.culls.mcmoderatorplus.commands.*;
import me.culls.mcmoderatorplus.listeners.InventoryListener;
import me.culls.mcmoderatorplus.listeners.LoginListener;
import me.culls.mcmoderatorplus.storage.BanManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class McModeratorPlus extends JavaPlugin {
    private static McModeratorPlus instance;
    private BanManager banManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        getDataFolder().mkdirs();

        banManager = new BanManager(this);
        banManager.load();

        // Commands
        getCommand("ban").setExecutor(new BanCommand(banManager));
        getCommand("tempban").setExecutor(new TempBanCommand(banManager));
        getCommand("banip").setExecutor(new BanIPCommand(banManager));
        getCommand("banlist").setExecutor(new BanListCommand(banManager));
        getCommand("banui").setExecutor(new BanUICommand(banManager));
        getCommand("unban").setExecutor(new UnbanCommand(banManager));
        getCommand("unbanip").setExecutor(new UnbanIPCommand(banManager));

        // Events
        getServer().getPluginManager().registerEvents(new LoginListener(banManager), this);
        getServer().getPluginManager().registerEvents(new InventoryListener(banManager), this);

        // periodic purge
        getServer().getScheduler().runTaskTimerAsynchronously(this, () -> {
            if (banManager != null) banManager.purgeExpiredTempBans();
        }, 20L * 30, 20L * 60);

        getLogger().info("mcModeratorPlus enabled");
    }

    @Override
    public void onDisable() {
        if (banManager != null) banManager.save();
        getLogger().info("mcModeratorPlus disabled");
    }

    public static McModeratorPlus getInstance() {
        return instance;
    }

    public BanManager getBanManager() {
        return banManager;
    }
}
