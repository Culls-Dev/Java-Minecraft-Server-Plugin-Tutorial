package me.culls.mcmoderatorplus.ui;

import me.culls.mcmoderatorplus.storage.BanManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BanUI {
    private static final int PAGE_SIZE = 45; // 5 rows for ban entries, last row = controls

    public static Inventory getBanInventory(BanManager manager, int page) {
        List<Map.Entry<String, String>> bans = new ArrayList<>(manager.getAllBans().entrySet());
        int totalPages = (int) Math.ceil((double) bans.size() / PAGE_SIZE);
        if (totalPages == 0) totalPages = 1;
        if (page < 1) page = 1;
        if (page > totalPages) page = totalPages;

        Inventory inv = Bukkit.createInventory(null, 54, "§cBan List (Page " + page + "/" + totalPages + ")");

        int startIndex = (page - 1) * PAGE_SIZE;
        int endIndex = Math.min(startIndex + PAGE_SIZE, bans.size());

        for (int i = startIndex; i < endIndex; i++) {
            Map.Entry<String, String> entry = bans.get(i);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            ItemMeta meta = head.getItemMeta();
            meta.setDisplayName("§c" + entry.getKey());
            List<String> lore = new ArrayList<>();
            lore.add("§7Reason: §f" + entry.getValue());
            lore.add("§7Click to unban");
            meta.setLore(lore);
            head.setItemMeta(meta);
            inv.setItem(i - startIndex, head);
        }

        // Navigation buttons
        if (page > 1) {
            ItemStack prev = new ItemStack(Material.ARROW);
            ItemMeta meta = prev.getItemMeta();
            meta.setDisplayName("§ePrevious Page");
            prev.setItemMeta(meta);
            inv.setItem(45, prev);
        }

        if (page < totalPages) {
            ItemStack next = new ItemStack(Material.ARROW);
            ItemMeta meta = next.getItemMeta();
            meta.setDisplayName("§eNext Page");
            next.setItemMeta(meta);
            inv.setItem(53, next);
        }

        // Close button
        ItemStack close = new ItemStack(Material.BARRIER);
        ItemMeta closeMeta = close.getItemMeta();
        closeMeta.setDisplayName("§cClose");
        close.setItemMeta(closeMeta);
        inv.setItem(49, close);

        return inv;
    }

    public static void handleClick(InventoryClickEvent e, BanManager manager) {
        if (e.getView().getTitle().startsWith("§cBan List")) {
            e.setCancelled(true);
            if (!(e.getWhoClicked() instanceof Player player)) return;
            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;
            String title = e.getView().getTitle();
            int currentPage = getCurrentPage(title);

            switch (clicked.getType()) {
                case PLAYER_HEAD -> {
                    String target = clicked.getItemMeta().getDisplayName().replace("§c", "");
                    if (manager.unban(target)) {
                        player.sendMessage("§aUnbanned " + target + ".");
                        player.openInventory(getBanInventory(manager, currentPage));
                    } else {
                        player.sendMessage("§cCould not unban " + target + ".");
                    }
                }
                case ARROW -> {
                    if (clicked.getItemMeta().getDisplayName().contains("Previous")) {
                        player.openInventory(getBanInventory(manager, currentPage - 1));
                    } else {
                        player.openInventory(getBanInventory(manager, currentPage + 1));
                    }
                }
                case BARRIER -> player.closeInventory();
                default -> {}
            }
        }
    }

    private static int getCurrentPage(String title) {
        try {
            String pageText = title.substring(title.indexOf("Page ") + 5, title.indexOf("/"));
            return Integer.parseInt(pageText.trim());
        } catch (Exception e) {
            return 1;
        }
    }
}
