package me.culls.mcmoderatorplus.storage;

import me.culls.mcmoderatorplus.McModeratorPlus;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.*;
import java.util.logging.Level;

public class BanManager {
    private final McModeratorPlus plugin;
    private final File bansFile;
    private final File ipBansFile;
    private FileConfiguration bansConfig;
    private FileConfiguration ipBansConfig;

    private final Map<String, BanRecord> bans = new HashMap<>();
    private final Map<String, IPBanRecord> ipBans = new HashMap<>();

    public BanManager(McModeratorPlus plugin) {
        this.plugin = plugin;
        this.bansFile = new File(plugin.getDataFolder(), "bans.yml");
        this.ipBansFile = new File(plugin.getDataFolder(), "ipbans.yml");
        ensureFiles();
    }

    private void ensureFiles() {
        try {
            if (!bansFile.exists()) {
                bansFile.getParentFile().mkdirs();
                bansFile.createNewFile();
                YamlConfiguration l = YamlConfiguration.loadConfiguration(bansFile);
                l.save(bansFile);
            }
            if (!ipBansFile.exists()) {
                ipBansFile.getParentFile().mkdirs();
                ipBansFile.createNewFile();
                YamlConfiguration l = YamlConfiguration.loadConfiguration(ipBansFile);
                l.save(ipBansFile);
            }
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Failed to create ban files", e);
        }
    }

    public void load() {
        bansConfig = YamlConfiguration.loadConfiguration(bansFile);
        ipBansConfig = YamlConfiguration.loadConfiguration(ipBansFile);

        bans.clear();
        ipBans.clear();

        if (bansConfig.isConfigurationSection("bans")) {
            for (String key : bansConfig.getConfigurationSection("bans").getKeys(false)) {
                String path = "bans." + key;
                String name = bansConfig.getString(path + ".name");
                String reason = bansConfig.getString(path + ".reason", "Banned");
                long until = bansConfig.getLong(path + ".until", -1L);
                String by = bansConfig.getString(path + ".by", "console");
                String ip = bansConfig.getString(path + ".ip", null);
                BanRecord r = new BanRecord(name, reason, until, by, ip);
                bans.put(name.toLowerCase(Locale.ROOT), r);
            }
        }

        if (ipBansConfig.isConfigurationSection("ipbans")) {
            for (String key : ipBansConfig.getConfigurationSection("ipbans").getKeys(false)) {
                String path = "ipbans." + key;
                String ip = ipBansConfig.getString(path + ".ip");
                String reason = ipBansConfig.getString(path + ".reason", "IP Banned");
                long until = ipBansConfig.getLong(path + ".until", -1L);
                String by = ipBansConfig.getString(path + ".by", "console");
                IPBanRecord r = new IPBanRecord(ip, reason, until, by);
                ipBans.put(ip, r);
            }
        }
    }

    public synchronized void save() {
        try {
            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(bansFile);
            cfg.set("bans", null);
            for (BanRecord r : bans.values()) {
                String key = r.getName().toLowerCase(Locale.ROOT);
                String path = "bans." + key;
                cfg.set(path + ".name", r.getName());
                cfg.set(path + ".reason", r.getReason());
                cfg.set(path + ".until", r.getUntil());
                cfg.set(path + ".by", r.getBy());
                cfg.set(path + ".ip", r.getIp());
            }
            cfg.save(bansFile);

            YamlConfiguration ipcfg = YamlConfiguration.loadConfiguration(ipBansFile);
            ipcfg.set("ipbans", null);
            for (IPBanRecord r : ipBans.values()) {
                String key = r.getIp().replace(".", "_");
                String path = "ipbans." + key;
                ipcfg.set(path + ".ip", r.getIp());
                ipcfg.set(path + ".reason", r.getReason());
                ipcfg.set(path + ".until", r.getUntil());
                ipcfg.set(path + ".by", r.getBy());
            }
            ipcfg.save(ipBansFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Failed to save ban files", e);
        }
    }

    public synchronized boolean isBanned(String playerName) {
        BanRecord r = bans.get(playerName.toLowerCase(Locale.ROOT));
        if (r == null) return false;
        if (r.isExpired()) {
            bans.remove(playerName.toLowerCase(Locale.ROOT));
            save();
            return false;
        }
        return true;
    }

    public synchronized Optional<BanRecord> getBan(String playerName) {
        BanRecord r = bans.get(playerName.toLowerCase(Locale.ROOT));
        if (r == null) return Optional.empty();
        if (r.isExpired()) {
            bans.remove(playerName.toLowerCase(Locale.ROOT));
            save();
            return Optional.empty();
        }
        return Optional.of(r);
    }

    public synchronized void ban(String name, String reason, long untilEpochMilli, String by, String ip) {
        BanRecord b = new BanRecord(name, reason, untilEpochMilli, by, ip);
        bans.put(name.toLowerCase(Locale.ROOT), b);
        save();
    }

    public synchronized boolean unban(String name) {
        String key = name.toLowerCase(Locale.ROOT);
        boolean exists = bans.remove(key) != null;
        if (exists) save();
        return exists;
    }

    public synchronized List<BanRecord> listBans() {
        purgeExpiredTempBans();
        List<BanRecord> list = new ArrayList<>(bans.values());
        list.sort(Comparator.comparing(BanRecord::getName));
        return list;
    }

    public synchronized void banIp(String ip, String reason, long untilEpochMilli, String by) {
        IPBanRecord r = new IPBanRecord(ip, reason, untilEpochMilli, by);
        ipBans.put(ip, r);
        save();
    }

    public synchronized boolean isIpBanned(String ip) {
        IPBanRecord r = ipBans.get(ip);
        if (r == null) return false;
        if (r.isExpired()) {
            ipBans.remove(ip);
            save();
            return false;
        }
        return true;
    }

    public synchronized Optional<IPBanRecord> getIpBan(String ip) {
        IPBanRecord r = ipBans.get(ip);
        if (r == null) return Optional.empty();
        if (r.isExpired()) {
            ipBans.remove(ip);
            save();
            return Optional.empty();
        }
        return Optional.of(r);
    }

    public synchronized boolean unbanIp(String ip) {
        boolean existed = ipBans.remove(ip) != null;
        if (existed) save();
        return existed;
    }

    public synchronized void purgeExpiredTempBans() {
        boolean changed = false;
        Iterator<Map.Entry<String, BanRecord>> it = bans.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, BanRecord> e = it.next();
            if (e.getValue().isExpired()) {
                it.remove();
                changed = true;
            }
        }
        Iterator<Map.Entry<String, IPBanRecord>> it2 = ipBans.entrySet().iterator();
        while (it2.hasNext()) {
            Map.Entry<String, IPBanRecord> e = it2.next();
            if (e.getValue().isExpired()) {
                it2.remove();
                changed = true;
            }
        }
        if (changed) save();
    }

    // Provide a map of all bans name->reason for UI
    public synchronized Map<String, String> getAllBans() {
        Map<String, String> out = new LinkedHashMap<>();
        List<BanRecord> list = listBans();
        for (BanRecord r : list) {
            out.put(r.getName(), r.getReason());
        }
        return out;
    }

    // Helper record classes
    public static class BanRecord {
        private final String name;
        private final String reason;
        private final long until; // -1 for permanent
        private final String by;
        private final String ip;

        public BanRecord(String name, String reason, long until, String by, String ip) {
            this.name = name;
            this.reason = reason;
            this.until = until;
            this.by = by;
            this.ip = ip;
        }

        public String getName() { return name; }
        public String getReason() { return reason; }
        public long getUntil() { return until; }
        public String getBy() { return by; }
        public String getIp() { return ip; }

        public boolean isPermanent() { return until <= 0; }
        public boolean isExpired() {
            return until > 0 && Instant.now().toEpochMilli() > until;
        }

        public String getRemaining() {
            if (isPermanent()) return "Permanent";
            long now = Instant.now().toEpochMilli();
            long ms = Math.max(0, until - now);
            long seconds = ms / 1000;
            long days = seconds / 86400;
            seconds %= 86400;
            long hours = seconds / 3600;
            seconds %= 3600;
            long minutes = seconds / 60;
            seconds %= 60;
            StringBuilder sb = new StringBuilder();
            if (days > 0) sb.append(days).append("d");
            if (hours > 0) sb.append(hours).append("h");
            if (minutes > 0) sb.append(minutes).append("m");
            if (seconds > 0 && sb.length() == 0) sb.append(seconds).append("s");
            if (sb.length() == 0) sb.append("0s");
            return sb.toString();
        }
    }

    public static class IPBanRecord {
        private final String ip;
        private final String reason;
        private final long until;
        private final String by;

        public IPBanRecord(String ip, String reason, long until, String by) {
            this.ip = ip;
            this.reason = reason;
            this.until = until;
            this.by = by;
        }

        public String getIp() { return ip; }
        public String getReason() { return reason; }
        public long getUntil() { return until; }
        public String getBy() { return by; }
        public boolean isPermanent() { return until <= 0; }
        public boolean isExpired() {
            return until > 0 && Instant.now().toEpochMilli() > until;
        }
        public String getRemaining() {
            if (isPermanent()) return "Permanent";
            long now = Instant.now().toEpochMilli();
            long ms = Math.max(0, until - now);
            long seconds = ms / 1000;
            long days = seconds / 86400;
            seconds %= 86400;
            long hours = seconds / 3600;
            seconds %= 3600;
            long minutes = seconds / 60;
            seconds %= 60;
            StringBuilder sb = new StringBuilder();
            if (days > 0) sb.append(days).append("d");
            if (hours > 0) sb.append(hours).append("h");
            if (minutes > 0) sb.append(minutes).append("m");
            if (seconds > 0 && sb.length() == 0) sb.append(seconds).append("s");
            if (sb.length() == 0) sb.append("0s");
            return sb.toString();
        }
    }
}
