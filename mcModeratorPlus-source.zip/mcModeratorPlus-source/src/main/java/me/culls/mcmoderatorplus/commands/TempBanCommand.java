package me.culls.mcmoderatorplus.commands;

import me.culls.mcmoderatorplus.storage.BanManager;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.time.Instant;
import java.util.Arrays;

public class TempBanCommand implements CommandExecutor {
    private final BanManager manager;

    public TempBanCommand(BanManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("mcmoderatorplus.tempban")) {
            sender.sendMessage("§cYou don't have permission to use this.");
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage("§eUsage: /tempban <player> <duration> [reason]");
            sender.sendMessage("§eDuration examples: 7d, 12h, 30m, 1d6h30m");
            return true;
        }

        String targetName = args[0];
        String durationStr = args[1];
        String reason = args.length > 2 ? String.join(" ", Arrays.copyOfRange(args, 2, args.length)) : "Temporarily banned";

        long durationMs;
        try {
            durationMs = parseDurationToMillis(durationStr);
            if (durationMs <= 0) throw new IllegalArgumentException();
        } catch (IllegalArgumentException ex) {
            sender.sendMessage("§cInvalid duration format. Examples: 7d, 12h, 30m, 1d6h30m");
            return true;
        }

        long until = Instant.now().toEpochMilli() + durationMs;

        Player online = org.bukkit.Bukkit.getPlayerExact(targetName);
        String ip = null;
        if (online != null) {
            if (online.getAddress() != null) ip = online.getAddress().getAddress().getHostAddress();
            online.kickPlayer("You are temporarily banned for " + durationStr + ". Reason: " + reason);
        }

        manager.ban(targetName, reason, until, sender.getName(), ip);
        Bukkit.broadcastMessage("§c[TempBan] " + targetName + " was temp-banned by " + sender.getName() + " for " + durationStr + " — " + reason);
        return true;
    }

    private static long parseDurationToMillis(String s) {
        s = s.toLowerCase();
        long total = 0L;
        StringBuilder num = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isDigit(c)) {
                num.append(c);
            } else {
                if (num.length() == 0) throw new IllegalArgumentException("Invalid duration");
                long val = Long.parseLong(num.toString());
                num.setLength(0);
                switch (c) {
                    case 'd': total += val * 24L * 60L * 60L * 1000L; break;
                    case 'h': total += val * 60L * 60L * 1000L; break;
                    case 'm': total += val * 60L * 1000L; break;
                    case 's': total += val * 1000L; break;
                    default: throw new IllegalArgumentException("Invalid time unit");
                }
            }
        }
        if (num.length() > 0) throw new IllegalArgumentException("Invalid trailing number");
        return total;
    }
}
