package me.culls.mcmoderatorplus.commands;

import me.culls.mcmoderatorplus.storage.BanManager;
import org.bukkit.command.*;

import java.util.List;

public class BanListCommand implements CommandExecutor {
    private final BanManager manager;
    private static final int PAGE_SIZE = 8;

    public BanListCommand(BanManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("mcmoderatorplus.banlist")) {
            sender.sendMessage("§cYou don't have permission to use this.");
            return true;
        }

        int page = 1;
        if (args.length >= 1) {
            try { page = Integer.parseInt(args[0]); } catch (NumberFormatException ignored) {}
        }

        List<BanManager.BanRecord> list = manager.listBans();
        int maxPages = Math.max(1, (int)Math.ceil((double)list.size() / PAGE_SIZE));
        page = Math.max(1, Math.min(page, maxPages));

        sender.sendMessage("§6---- Ban List (Page " + page + "/" + maxPages + ") ----");
        int start = (page - 1) * PAGE_SIZE;
        int end = Math.min(list.size(), start + PAGE_SIZE);
        for (int i = start; i < end; i++) {
            BanManager.BanRecord r = list.get(i);
            sender.sendMessage("§c" + r.getName() + " §7| " + (r.isPermanent() ? "Permanent" : r.getRemaining()) + " §8| §e" + r.getReason());
        }
        return true;
    }
}
