package me.culls.mcmoderatorplus.listeners;

import me.culls.mcmoderatorplus.storage.BanManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;

import java.net.InetAddress;
import java.util.Optional;

public class LoginListener implements Listener {
    private final BanManager manager;

    public LoginListener(BanManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        String name = e.getName();
        InetAddress addr = e.getAddress();
        String ip = addr != null ? addr.getHostAddress() : null;

        // Check player ban
        Optional<BanManager.BanRecord> ban = manager.getBan(name);
        if (ban.isPresent()) {
            BanManager.BanRecord r = ban.get();
            String reason = r.getReason();
            String message;
            if (r.isPermanent()) {
                message = "You are permanently banned. Reason: " + reason;
            } else {
                message = "You are banned for " + r.getRemaining() + ". Reason: " + reason;
            }
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED, message);
            return;
        }

        // Check ip ban
        if (ip != null) {
            Optional<BanManager.IPBanRecord> ipban = manager.getIpBan(ip);
            if (ipban.isPresent()) {
                BanManager.IPBanRecord r = ipban.get();
                String reason = r.getReason();
                String message;
                if (r.isPermanent()) {
                    message = "Your IP is permanently banned. Reason: " + reason;
                } else {
                    message = "Your IP is banned for " + r.getRemaining() + ". Reason: " + reason;
                }
                e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, message);
            }
        }
    }
}
